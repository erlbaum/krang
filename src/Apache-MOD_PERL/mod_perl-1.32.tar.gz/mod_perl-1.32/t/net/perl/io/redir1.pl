#!perl
use strict;
my $r = shift;
$r->internal_redirect('/perl/io/redir2.pl');

#!perl
my($r, @args) = @_;

for (@args) {
    print "$_\n";
}


package Apache::BadSyntax;

for (1..2) {

sub foo;

1;

__END__

#!/usr/bin/perl -w
use strict;
use warnings;
use Krang::ClassFactory qw(pkg);
use Krang::ClassLoader DB => 'dbh';
use Krang::ClassLoader qw(Conf);

foreach my $instance (pkg('Conf')->instances) {
    pkg('Conf')->instance($instance);
    my $dbh = dbh();
    $dbh->do('DROP TABLE IF EXISTS cleaned');
}
print STDERR "Dropped cleaned tables.\n";


CREATE TABLE cleaned (
        module VARCHAR(255) NOT NULL,
        count  INT NOT NULL DEFAULT 0
);

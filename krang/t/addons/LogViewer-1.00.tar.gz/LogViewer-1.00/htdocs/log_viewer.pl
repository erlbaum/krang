#!/usr/bin/perl -w
use Krang::ErrorHandler;
use CGI qw(header);
use Krang::Conf qw(KrangRoot);
use Krang::Log qw(critical);

critical("HI MOM!");
open LOG, "tail -1 " . KrangRoot . "/logs/krang.log |" or die $!;
print header, join('<br>', <LOG>);

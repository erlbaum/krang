package LogViewer;
use strict;
use warnings;

sub navigation_handler {
    my ($pkg, $tree) = @_;
    
    my $node = $tree->new_daughter();
    $node->name('Log Tools');

    $node = $node->new_daughter();
    $node->name('View Log');
    $node->link('log_viewer.pl');
}

1;

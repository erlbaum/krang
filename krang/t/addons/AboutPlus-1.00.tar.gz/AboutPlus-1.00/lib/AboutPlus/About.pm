package AboutPlus::About;
use strict;
use warnings;

use base 'Krang::CGI::About';

sub load_tmpl {
    my $self = shift;
    my $template = $self->SUPER::load_tmpl(@_);
    $template->param(cgi_mode => !$ENV{MOD_PERL});
    return $template;
}

sub show {
    my $self = shift;
    my $output = $self->SUPER::show(@_);
    return $output . 
      "<p>PLUS BIG IMPROVEMENTS!";
}

1;

package LazyLoader::Story;
use strict;
use warnings;

use Carp qw(croak);

use Object::Realize::Later
  ( becomes => 'Krang::Story',
    realize => 'realize',
    warn_realize => 1,
  );

sub story_id {
    return shift->{story_id};
}

sub realize {
    my $self = shift;
    my ($story_id, $find_args) = @$self{('story_id', 'find_args')};

    # construct args for find
    my %args = ( story_id => $self->{story_id} );
    $args{version} = $find_args->{version} if $find_args->{version};
    
    my ($real) = Krang::Story->find(%args);
    if ($real) {
        %$self = %$real;
        bless $self, 'Krang::Story';
    }
    return $self;
}

sub find {
    my ($pkg, %args) = @_;

    # allow non-object loads through
    return Krang::Story->find(%args)
      if $args{ids_only} or $args{count};
    
    # save original args and remove problematic ones
    my %orig = %args;
    delete $args{version};
    
    # otherwise, just load IDs and mark it
    my @ids = Krang::Story->find(%args, ids_only => 1);

    return map { bless { story_id => $_, find_args => \%orig }, $pkg } @ids;
}

1;
